
    function toggleVisibility(){
    const useless=document.getElementById('useless-paragraph');

    
    if(useless.style.display==='none'){
        useless.style.display='block';
    }
    else{
        useless.style.display='none'
    }
}


