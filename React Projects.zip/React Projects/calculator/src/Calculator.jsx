import { useState } from "react";
import "./Calculator.css";

function Calculator() {
  const [num1, setNum1] = useState("");
  const [num2, setNum2] = useState("");
  const [result, setResult] = useState("");
  const [dark, setDark] = useState(false);

  const calculate = (operation) => {
    const a = Number(num1);
    const b = Number(num2);

    if (num1 === "" || num2 === "") {
      setResult("Enter both numbers");
      return;
    }

    switch (operation) {
      case "add":
        setResult(a + b);
        break;
      case "subtract":
        setResult(a - b);
        break;
      case "multiply":
        setResult(a * b);
        break;
      case "divide":
        setResult(b !== 0 ? a / b : "Cannot divide by zero");
        break;
      default:
        break;
    }
  };

  const clearAll = () => {
    setNum1("");
    setNum2("");
    setResult("");
  };

  return (
    <div className={dark ? "calculator dark" : "calculator"}>
      <div className="header">
        <h3>Calculator</h3>
        <button className="theme-btn" onClick={() => setDark(!dark)}>
          🌙
        </button>
      </div>

      <input
        type="number"
        placeholder="Enter number 1"
        value={num1}
        onChange={(e) => setNum1(e.target.value)}
      />

      <input
        type="number"
        placeholder="Enter number 2"
        value={num2}
        onChange={(e) => setNum2(e.target.value)}
      />

      <div className="buttons">
        <button onClick={() => calculate("add")}>+</button>
        <button onClick={() => calculate("subtract")}>-</button>
        <button onClick={() => calculate("multiply")}>×</button>
        <button onClick={() => calculate("divide")}>÷</button>
      </div>

      <button className="clear-btn" onClick={clearAll}>
        C
      </button>

      <div className="result">
        Result: <span>{result}</span>
      </div>
    </div>
  );
}

export default Calculator;
