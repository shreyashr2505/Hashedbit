import { useLocation } from "react-router-dom";

function Confirmation() {
  const { state } = useLocation();
  const bookingId = Math.floor(Math.random() * 1000000);

  return (
    <div>
      <h2>Seat Booked Successfully 🎉</h2>
      <p><strong>Booking ID:</strong> {bookingId}</p>
      <p>Name: {state.name}</p>
      <p>Email: {state.email}</p>
      <p>Mobile: {state.mobile}</p>
    </div>
  );
}

export default Confirmation;
