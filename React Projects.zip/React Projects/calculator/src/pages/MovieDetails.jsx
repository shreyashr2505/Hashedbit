import { useParams, useNavigate } from "react-router-dom";
import movies from "../data";

function MovieDetails() {
  const { id } = useParams();
  const navigate = useNavigate();

  const movie = movies.find((m) => m.id === Number(id));

  return (
    <div style={{ textAlign: "center" }}>
      <h2>{movie.title}</h2>

      <img
        src={movie.img}
        alt={movie.title}
        style={{
          width: "200px",
          height: "300px",
          objectFit: "cover",
          borderRadius: "8px"
        }}
      />

      <br /><br />

      <button onClick={() => navigate("/book")}>
        Book Seat
      </button>
    </div>
  );
}

export default MovieDetails;
