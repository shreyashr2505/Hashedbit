const str='I love my India';

const reverse=str.split(" ").reverse().join(" ");;
console.log(reverse); 