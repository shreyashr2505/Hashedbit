reverse=(string)=>{
    return string.split('').reverse().join('');;
}
console.log(reverse('Shreyash'));