import { useState } from "react";

function Todo() {
  const [input, setInput] = useState("");
  const [todos, setTodos] = useState([]);
  const [editIndex, setEditIndex] = useState(null);

  const addOrUpdateTask = () => {
    if (input.trim() === "") return;

    let updatedTodos;

    if (editIndex !== null) {
      // Update task
      updatedTodos = todos.map((task, index) =>
        index === editIndex ? input.trim() : task
      );
      setEditIndex(null);
    } else {
      // Add task
      updatedTodos = [...todos, input.trim()];
    }

    setTodos(updatedTodos.sort());
    setInput("");
  };

  const deleteTask = (index) => {
    setTodos(todos.filter((_, i) => i !== index));
  };

  const editTask = (index) => {
    setInput(todos[index]);
    setEditIndex(index);
  };

  return (
    <div>
      <h2>Todo List</h2>

      <input
        type="text"
        placeholder="Enter task"
        value={input}
        onChange={(e) => setInput(e.target.value)}
      />

      <button onClick={addOrUpdateTask}>
        {editIndex !== null ? "Update" : "Add"}
      </button>

      <ul>
        {todos.map((task, index) => (
          <li key={index}>
            {task}{" "}
            <button onClick={() => editTask(index)}>Edit</button>{" "}
            <button onClick={() => deleteTask(index)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Todo;
