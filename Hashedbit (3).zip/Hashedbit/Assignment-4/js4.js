// main div
const textContainer = document.getElementById("text-container");

// change color button
document.getElementById("colorchange").addEventListener("click", function () {
  const c = document.getElementById("colorbox").value;
  textContainer.style.color = c;
});

// font size slider
document.getElementById("fontsize").addEventListener("input", function (e) {
  textContainer.style.fontSize = `${e.target.value}px`;
});

// Italic button toggle
document.getElementById("italic").addEventListener("click", function () {
  textContainer.style.fontStyle =
    textContainer.style.fontStyle === "italic" ? "normal" : "italic";
});

// Underline button toggle
document.getElementById("underline").addEventListener("click", function () {
  textContainer.style.textDecoration =
    textContainer.style.textDecoration === "underline"
      ? "none"
      : "underline";
});

// Bold button toggle
document.getElementById("bold").addEventListener("click", function () {
  textContainer.style.fontWeight =
    textContainer.style.fontWeight === "bold" ? "normal" : "bold";
});

// font family dropdown
document.getElementById("list").addEventListener("change", function (e) {
  textContainer.style.fontFamily = e.target.value;
});

// show CSS properties
document.getElementById("getstyle").addEventListener("click", function () {
  const st = window.getComputedStyle(textContainer);

  const props = [
    `color: ${st.color};`,
    `font-size: ${st.fontSize};`,
    `font-family: ${st.fontFamily};`,
    `text-decoration: ${st.textDecorationLine};`,
    `font-style: ${st.fontStyle};`,
    `font-weight: ${st.fontWeight};`
  ];

  document.getElementById("css-props").innerText = props.join(" ");
});
