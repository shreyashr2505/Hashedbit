import { BrowserRouter, Routes, Route, Link } from "react-router-dom";

// Existing apps
import Calculator from "./Calculator";
import Todo from "./Todo";
import IPLTable from "./IPLTable";

// Movie Booking pages
import Movies from "./pages/Movies";
import MovieDetails from "./pages/MovieDetails";
import BookingForm from "./pages/BookingForm";
import Confirmation from "./pages/Confirmation";

function App() {
  return (
    <BrowserRouter>
      {/* Simple navigation (no CSS needed) */}
      <nav>
        <Link to="/calculator">Calculator</Link> |{" "}
        <Link to="/todo">Todo</Link> |{" "}
        <Link to="/ipl">IPL Table</Link> |{" "}
        <Link to="/movies">Movies</Link>
      </nav>

      <hr />

      <Routes>
        {/* Other Apps */}
        <Route path="/calculator" element={<Calculator />} />
        <Route path="/todo" element={<Todo />} />
        <Route path="/ipl" element={<IPLTable />} />

        {/* Movie Booking App */}
        <Route path="/movies" element={<Movies />} />
        <Route path="/movie/:id" element={<MovieDetails />} />
        <Route path="/book" element={<BookingForm />} />
        <Route path="/confirm" element={<Confirmation />} />

        {/* Default Route */}
        <Route path="*" element={<Movies />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
