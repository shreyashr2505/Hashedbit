import movies from "../data";
import { useNavigate } from "react-router-dom";

function Movies() {
  const navigate = useNavigate();

  return (
    <div>
      <h2>Movies</h2>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(4, 1fr)",
          gap: "20px",
        }}
      >
        {movies.map((movie) => (
          <div
            key={movie.id}
            onClick={() => navigate(`/movie/${movie.id}`)}
            style={{ cursor: "pointer", textAlign: "center" }}
          >
            <img
              src={movie.img}
              alt={movie.title}
              style={{
                width: "120px",
                height: "180px",
                objectFit: "cover",
                borderRadius: "6px"
              }}
            />
            <p>{movie.title}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Movies;
