function countWords(text) {
  return text.trim().split(/\s+/).length;
}

console.log(countWords("I love my country India"));
