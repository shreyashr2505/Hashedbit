// Create a new div element
const div = document.createElement("div");

// Add text to the div
div.innerText = "I am a newly created div";

// Apply styles dynamically
div.style.width = "300px";
div.style.height = "100px";
div.style.backgroundColor = "lightblue";
div.style.color = "black";
div.style.display = "flex";
div.style.justifyContent = "center";
div.style.alignItems = "center";
div.style.margin = "20px auto";
div.style.fontSize = "18px";
div.style.borderRadius = "8px";

// Append the div to the body
document.body.appendChild(div);
