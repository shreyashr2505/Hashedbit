const movies = [
  {
    id: 1,
    title: "Avengers: Endgame",
    img: "https://m.media-amazon.com/images/I/81ExhpBEbHL._AC_SY679_.jpg",
  },
  {
    id: 2,
    title: "The Dark Knight",
    img: "https://film-book.com/wp-content/uploads/2012/06/the-dark-knight-trilogy-movie-poster-01.jpeg",
  },
  {
    id: 3,
    title: "Inception",
    img: "https://m.media-amazon.com/images/I/91kFYg4fX3L._AC_SY679_.jpg",
  },
  {
    id: 4,
    title: "Joker",
    img: "https://www.vintagemovieposters.co.uk/wp-content/uploads/2020/01/IMG_2893-636x941.jpeg",
  },
  {
    id: 5,
    title: "Interstellar",
    img: "https://m.media-amazon.com/images/I/91kFYg4fX3L._AC_SY679_.jpg",
  },
  {
    id: 6,
    title: "Gladiator",
    img: "https://m.media-amazon.com/images/I/71rNJQ2g-EL._AC_SY679_.jpg",
  },
  {
    id: 7,
    title: "Avatar",
    img: "https://m.media-amazon.com/images/I/71niXI3lxlL._AC_SY679_.jpg",
  },
  {
    id: 8,
    title: "Titanic",
    img: "https://cdn11.bigcommerce.com/s-yshlhd/images/stencil/608x608/products/5647/174920/full.titanic-1sh-19559__50774.1671398387.jpg?c=2",
  },
  {
    id: 9,
    title: "Spider-Man: No Way Home",
    img: "https://letsgotothemovies.com/wp-content/uploads/2021/11/spiderman_no_way_home.jpg",
  },
  {
    id: 10,
    title: "Doctor Strange",
    img: "https://m.media-amazon.com/images/I/814mye5CwKL._AC_SL1111_.jpg",
  },
  {
    id: 11,
    title: "Iron Man",
    img: "https://m.media-amazon.com/images/I/61yvz+ELKyS._SY741_.jpg",
  },
  {
    id: 12,
    title: "Black Panther",
    img: "https://m.media-amazon.com/images/I/81dae9nZFBS._SY741_.jpg",
  },
  {
    id: 13,
    title: "Thor: Ragnarok",
    img: "https://m.media-amazon.com/images/I/71K9CbNZPsL._AC_SY679_.jpg",
  },
  {
    id: 14,
    title: "Captain America: Civil War",
    img: "https://www.vintagemovieposters.co.uk/wp-content/uploads/2021/12/IMG_4239-scaled.jpeg",
  },
  {
    id: 15,
    title: "Transformers",
    img: "https://m.media-amazon.com/images/I/819iPEDvAzL._SY879_.jpg",
  },
  {
    id: 16,
    title: "Fast & Furious 7",
    img: "https://mir-s3-cdn-cf.behance.net/project_modules/fs_webp/972d5811533181.56275c53e3d0c.jpg",
  }
];

export default movies;
